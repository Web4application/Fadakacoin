# Fadaka Blockchain

CLI scaffolded structure for upgradeable contracts and fullstack Web3 dApp.